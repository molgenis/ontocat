package uk.ac.ebi.ontocat.special;

/**
 * Author: Natalja Kurbatova
 * Date: 2010-09-20
 */

import java.io.File;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;

import uk.ac.ebi.ontocat.Ontology;
import uk.ac.ebi.ontocat.OntologyService;
import uk.ac.ebi.ontocat.OntologyServiceException;
import uk.ac.ebi.ontocat.OntologyTerm;
import uk.ac.ebi.ontocat.OntologyService.SearchOptions;
import uk.ac.ebi.ontocat.bioportal.BioportalOntologyService;
import uk.ac.ebi.ontocat.file.FileOntologyService;
import uk.ac.ebi.ontocat.ols.OlsOntologyService;

public class OntologyParser {

	private FileOntologyService os;
	private Ontology ontology;

	/**
	 * Creates instance of OntologyParser for EFO
	 * 
	 * @return OntologyParser object
	 */
	public OntologyParser() {

		// default is EFO last version
		try {

			// Instantiate a FileOntologyService
			os = new FileOntologyService(
					new URI(
							"http://efo.svn.sourceforge.net/viewvc/efo/trunk/src/efoinowl/InferredEFOOWLview/EFO_inferred.owl"));

			// Use a non-SKOS annotation for synonyms
			for (Ontology ot : os.getOntologies()) {
				ontology = ot;
				// if
				// (ontology.getOntologyAccession().equals("http://www.ebi.ac.uk/efo/efo.owl"))
				// ontology.setOntologyAccession("http://www.ebi.ac.uk/efo/");
				System.out.println(ot);
			}

			os.setSynonymSlot("alternative_term");
		} catch (Exception e) {
			System.out
					.println("Sorry, OntologyParser for EFO http://efo.svn.sourceforge.net/viewvc/efo/trunk/src/efoinowl/InferredEFOOWLview/EFO_inferred.owl can't be created.");
		}

	}

	/**
	 * Creates instance of OntologyParser from provided file or URL OWL and OBO
	 * formats are supported
	 * 
	 * @param pathToOntology
	 *            words to search
	 * @return OntologyParser object
	 */
	public OntologyParser(String pathToOntology) {

		try {

			File file = new File(pathToOntology);
			URI uri = new URI(pathToOntology);

			// Instantiate a FileOntologyService
			os = new FileOntologyService(uri);
			// Use a non-SKOS annotation for synonyms

			for (Ontology ot : os.getOntologies()) {
				ontology = ot;
				// if
				// (ontology.getOntologyAccession().equals("http://www.ebi.ac.uk/efo/efo.owl"))
				// ontology.setOntologyAccession("http://www.ebi.ac.uk/efo/");
			}

			os.setSynonymSlot("alternative_term");

		} catch (Exception e) {
			System.out
					.println("Sorry, OntologyParser for " + pathToOntology + " can't be created.");
		}

	}

	/**
	 * Searches for text in OLS (Ontology Lookup Service) ontologies
	 * 
	 * @param text
	 *            words to search
	 * @return collection of terms
	 */
	public Set<String> searchTermInOLS(String text) throws OntologyServiceException {
		Set<String> result = new HashSet<String>();
		// Instantiate OLS service
		OntologyService los = new OlsOntologyService();

		// Find all terms containing string text
		for (OntologyTerm ot : los.searchAll(text, SearchOptions.EXACT,
				SearchOptions.INCLUDE_PROPERTIES))
			result.add(ot.getAccession() + " Ontology: " + ot.getOntologyAccession());

		return result;
	}

	/**
	 * Searches for text in Bioportal ontologies
	 * 
	 * @param text
	 *            words to search
	 * @return collection of terms
	 */
	public Set<String> searchTermInBioportal(String text) throws OntologyServiceException {

		Set<String> result = new HashSet<String>();
		// Instantiate Bioportal service
		OntologyService los = new BioportalOntologyService();

		// Find all terms containing string text
		for (OntologyTerm ot : los.searchAll(text, SearchOptions.EXACT,
				SearchOptions.INCLUDE_PROPERTIES))
			result.add(ot.getAccession() + " Ontology: " + ot.getOntologyAccession());

		return result;
	}

	/**
	 * Searches for term in ontology
	 * 
	 * @param text
	 *            words to search
	 * @return set of term accessions
	 */
	public Set<String> searchTerm(String text) throws OntologyServiceException {

		Set<String> result = new HashSet<String>();

		for (OntologyTerm ot : os.searchAll(text))
			result.add(ot.getAccession());

		return result;
	}

	/**
	 * Returns collection of all terms
	 * 
	 * @return collection of all terms
	 */
	public Collection<OntologyTerm> getAllTerms() throws OntologyServiceException {

		return os.getAllTerms(ontology.getOntologyAccession());
	}

	/**
	 * Returns collection of all term accessions
	 * 
	 * @return collection of all term accessions
	 */
	public Set<String> getAllTermIds() throws OntologyServiceException {

		HashSet<String> result = new HashSet<String>();
		for (OntologyTerm ot : os.getAllTerms(ontology.getOntologyAccession()))
			result.add(ot.getAccession());

		return result;
	}

	/**
	 * Searches for prefix in ontology
	 * 
	 * @param prefix
	 *            prefix to search
	 * @return set of string term accessions
	 */
	public Set<String> searchTermPrefix(String prefix) throws OntologyServiceException {

		String lprefix = prefix.toLowerCase();
		Set<String> result = new HashSet<String>();

		for (OntologyTerm ot : os.getAllTerms(ontology.getOntologyAccession())) {
			if (ot.getLabel().toLowerCase().startsWith(lprefix)
					|| ot.getAccession().toLowerCase().startsWith(lprefix)) {
				result.add(ot.getAccession());
			} else
				for (String alt : os.getSynonyms(ot))
					if (alt.toLowerCase().startsWith(lprefix)) {
						result.add(ot.getAccession());
						break;
					}
		}
		return result;
	}

	private void collectSubTree(OntologyTerm currentNode, List<OntologyTerm> result,
			List<OntologyTerm> pathres, Set<String> allNodes, Set<String> visited, int depth,
			boolean printing) throws OntologyServiceException {
		if (printing && !allNodes.contains(currentNode.getAccession())) {
			printing = false;
		}

		boolean started = false;
		if (!printing && allNodes.contains(currentNode.getAccession())
				&& !visited.contains(currentNode.getAccession())) {
			printing = true;
			pathres = new ArrayList<OntologyTerm>();
			started = true;
		}

		if (printing) {
			pathres.add(currentNode);// newTerm(currentNode, depth)
			visited.add(currentNode.getAccession());
			for (OntologyTerm child : os.getChildren(currentNode))
				collectSubTree(child, result, pathres, allNodes, visited, depth + 1, true);
		} else {
			for (OntologyTerm child : os.getChildren(currentNode))
				collectSubTree(child, result, null, allNodes, visited, 0, false);
		}

		if (started) {
			result.addAll(pathres);
		}
	}

	/**
	 * Creates flat subtree representation ordered in natural print order, each
	 * self-contained sub-tree starts from depth=0
	 * 
	 * @param ids
	 *            marked IDs
	 * @return list of Term's
	 */
	public List<OntologyTerm> getSubTree(Set<String> ids) throws OntologyServiceException {

		List<OntologyTerm> result = new ArrayList<OntologyTerm>();
		Set<String> visited = new HashSet<String>();

		for (OntologyTerm root : os.getRootTerms(ontology.getOntologyAccession())) {
			collectSubTree(root, result, null, ids, visited, 0, false);
		}

		return result;
	}

	private void collectTreeDownTo(Iterable<OntologyTerm> nodes, Stack<OntologyTerm> path,
			List<OntologyTerm> result, int depth) throws OntologyServiceException {

		OntologyTerm next = path.pop();

		for (OntologyTerm n : nodes) {
			result.add(n);
			if (n.equals(next) && !path.empty())
				collectTreeDownTo(os.getChildren(n), path, result, depth + 1);
		}

	}

	/**
	 * Creates flat subtree representation of tree "opened" down to specified
	 * node, hence displaying all its parents first and then a tree level,
	 * containing specified node
	 * 
	 * @param id
	 *            term id
	 * @return list of Term's
	 */
	public List<OntologyTerm> getTreeDownTo(String id) throws OntologyServiceException {

		List<OntologyTerm> result = new ArrayList<OntologyTerm>();

		Stack<OntologyTerm> path = new Stack<OntologyTerm>();
		OntologyTerm node = os.getTerm(id);
		while (true) {
			path.push(node);
			if (os.getParents(node).isEmpty())
				break;
			node = os.getParents(node).get(0);
		}

		collectTreeDownTo(os.getRootTerms(ontology.getOntologyAccession()), path, result, 0);

		return result;
	}

	/**
	 * Returns set of root node accessions
	 * 
	 * @return set of root node accesions
	 */
	public Set<String> getRootIds() throws OntologyServiceException {
		Set<String> result = new HashSet<String>();
		for (OntologyTerm n : os.getRootTerms(ontology.getOntologyAccession())) {
			result.add(n.getAccession());
		}
		return result;
	}

	/**
	 * Returns list of root terms
	 * 
	 * @return list of terms
	 */
	public List<OntologyTerm> getRoots() throws OntologyServiceException {

		return os.getRootTerms(ontology.getOntologyAccession());

	}

	/**
	 * Returns set of branch root accessions. Method specific for EFO ontology
	 * 
	 * @return set of EFO branch root accessions
	 */
	public Set<String> getEFOBranchRootIds() throws OntologyServiceException {

		Set<String> result = new HashSet<String>();
		for (OntologyTerm n : os.getAllTerms(ontology.getOntologyAccession())) {
			if (isEFOBranchRoot(n))
				result.add(n.getAccession());
		}
		return result;
	}

	/**
	 * Returns collection of term's direct children
	 * 
	 * @param accession
	 *            term accession
	 * @return collection of terms, null if term is not found
	 */
	public Collection<OntologyTerm> getTermChildren(String accession)
			throws OntologyServiceException {

		List<OntologyTerm> result = new ArrayList<OntologyTerm>();
		OntologyTerm term = os.getTerm(accession);
		if (term == null)
			return null;
		for (OntologyTerm ot : os.getChildren(term))
			result.add(ot);

		return result;

	}

	/**
	 * Returns collection of term's direct parents
	 * 
	 * @param accession
	 *            term accession
	 * @return collection of terms, null if term is not found
	 */
	public Collection<OntologyTerm> getTermParents(String accession)
			throws OntologyServiceException {

		List<OntologyTerm> result = new ArrayList<OntologyTerm>();
		OntologyTerm term = os.getTerm(accession);
		if (term == null)
			return null;
		for (OntologyTerm ot : os.getParents(term))
			result.add(ot);

		return result;
	}

	/**
	 * Returns collection of term's all children
	 * 
	 * @param accession
	 *            term accession
	 * @return collection of terms, null if term is not found
	 */
	public Collection<OntologyTerm> getAllTermChildren(String accession)
			throws OntologyServiceException {

		List<OntologyTerm> result = new ArrayList<OntologyTerm>();
		OntologyTerm term = os.getTerm(accession);
		if (term == null)
			return null;
		for (OntologyTerm ot : os.getAllChildren(term))
			result.add(ot);
		return result;

	}

	/**
	 * Returns collection of term's all parents
	 * 
	 * @param accession
	 *            term accession
	 * @return collection of terms, null if term is not found
	 */
	public Collection<OntologyTerm> getAllTermParents(String accession)
			throws OntologyServiceException {

		List<OntologyTerm> result = new ArrayList<OntologyTerm>();
		OntologyTerm term = os.getTerm(accession);
		if (term == null)
			return null;
		for (OntologyTerm ot : os.getAllParents(term))
			result.add(ot);
		return result;
	}

	/**
	 * Returns set of term's definitions if there are some
	 * 
	 * @param accession
	 *            term accession
	 * @return set of term's definitions, null if term is not found
	 */
	public Set<String> getDefinitions(String accession) throws OntologyServiceException {

		Set<String> result = new HashSet<String>();
		OntologyTerm term = os.getTerm(accession);
		if (term == null)
			return null;

		for (String definition : os.getDefinitions(term))
			result.add(definition);

		return result;
	}

	/**
	 * Returns set of term's synonyms if there are some
	 * 
	 * @param accession
	 *            term accession
	 * @return set of term's synonyms, null if term is not found
	 */
	public Set<String> getSynonyms(String accession) throws OntologyServiceException {
		Set<String> result = new HashSet<String>();
		OntologyTerm term = os.getTerm(accession);
		if (term == null)
			return null;

		for (String synonym : os.getSynonyms(term))
			result.add(synonym);

		return result;
	}

	/**
	 * Fetch term label by accession
	 * 
	 * @param accession
	 *            term accession
	 * @return term label
	 */
	public String getTermNameById(String accession) throws OntologyServiceException {

		OntologyTerm term = os.getTerm(accession);
		return term == null ? null : term.getLabel();
	}

	/**
	 * Check if term is here
	 * 
	 * @param accession
	 *            term accession
	 * @return true if yes
	 */
	public boolean hasTerm(String accession) throws OntologyServiceException {

		OntologyTerm node = os.getTerm(accession);
		return node != null;
	}

	/**
	 * Fetch term by accession
	 * 
	 * @param accession
	 *            term accession
	 * @return external term representation if found in ontology, null otherwise
	 */
	public OntologyTerm getTermById(String accession) throws OntologyServiceException {

		OntologyTerm term = os.getTerm(accession);
		return term == null ? null : term;

	}

	/**
	 * Returns collection of accessions of node itself and all its children
	 * recursively
	 * 
	 * @param accession
	 *            term accession
	 * @return collection of accessions, empty if term is not found
	 */
	public Collection<String> getTermAndAllChildrenIds(String accession)
			throws OntologyServiceException {
		OntologyTerm term = os.getTerm(accession);
		List<String> ids = new ArrayList<String>(term == null ? 0 : os.getChildren(term).size());
		if (term != null) {
			for (OntologyTerm child : os.getAllChildren(term))
				ids.add(child.getAccession());

			ids.add(term.getAccession());
		}

		return ids;
	}

	/**
	 * Returns if term is branch root EFO term
	 * 
	 * @param term
	 *            OntologyTerm of interest
	 * @return if term is branch root term
	 */
	public boolean isEFOBranchRoot(OntologyTerm term) throws OntologyServiceException {

		boolean result = false;
		Map<String, List<String>> ann = os.getAnnotations(term);
		Iterator it = ann.entrySet().iterator();

		while (it.hasNext()) {
			Map.Entry pairs = (Map.Entry) it.next();
			if (pairs.getKey().equals("branch_class"))
				result = true;
		}

		return result;
	}

	/**
	 * Returns if term is root ontology term
	 * 
	 * @param term
	 *            OntologyTerm of interest
	 * @return if term is root ontology term
	 */
	public boolean isRoot(OntologyTerm term) throws OntologyServiceException {

		boolean result = false;
		for (OntologyTerm ot : os.getRootTerms(ontology.getOntologyAccession()))
			if (ot.equals(term))
				result = true;

		return result;
	}

	/**
	 * Returns parsed ontology description
	 * 
	 * @return ontology description: accession, version
	 */
	public String getOntologyDescription() throws OntologyServiceException {

		String result = "";
		result = "Accession: " + ontology.getOntologyAccession();
		result = result + " Version: " + ontology.getVersionNumber();
		result = result + " Label: " + ontology.getLabel();
		result = result + " Abbreviation: " + ontology.getAbbreviation();
		result = result + " Description: " + ontology.getDescription();
		result = result + " Release date: " + ontology.getDateReleased();

		return result;

	}

	/**
	 * Returns parsed ontology accession
	 * 
	 * @return ontology accession
	 */
	public String getOntologyAccession() throws OntologyServiceException {

       return ontology.getOntologyAccession();

}

}
