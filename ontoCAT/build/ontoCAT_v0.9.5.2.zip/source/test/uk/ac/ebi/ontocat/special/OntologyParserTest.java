package uk.ac.ebi.ontocat.special;

import java.net.URI;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;
import org.junit.BeforeClass;
import org.junit.Test;

import uk.ac.ebi.ontocat.OntologyService;
import uk.ac.ebi.ontocat.OntologyServiceException;
import uk.ac.ebi.ontocat.OntologyTerm;
import uk.ac.ebi.ontocat.file.FileOntologyService;

public class OntologyParserTest {
	protected static OntologyService os;
	protected static final Logger log = Logger.getLogger(OntologyParserTest.class);

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		URI uri = new URI(
				"http://efo.svn.sourceforge.net/viewvc/efo/trunk/src/efoinowl/InferredEFOOWLview/EFO_inferred.owl");

		OntologyService os = new FileOntologyService(uri);
		log.info(os.getOntologies().get(0).getOntologyAccession());
	}

	Set<String> efo_terms;

	@Test
	public void testParser() throws OntologyServiceException {

		efo_terms = new HashSet<String>();


		OntologyParser op = new OntologyParser(
				"http://efo.svn.sourceforge.net/viewvc/efo/trunk/src/efoinowl/InferredEFOOWLview/EFO_inferred.owl");
			System.out.println(op.getOntologyAccession());
			System.out.println(op.getOntologyDescription());

			// OntologyTerm ot = op.getTermById("EFO_0000322");
			System.out.println("Not All:");
			for (OntologyTerm ot : op.getTermParents("EFO_0000322"))

				System.out.println(ot);
			System.out.println("All:");
			for (OntologyTerm ot : op.getTreeDownTo("EFO_0002936"))
				System.out.println(ot);




	   }
}